<?php
    return [
        "panel1" => "Gambaran keseluruhan kemajuan aktiviti",
        "panel2" => "Dilantik Mengikut Jabatan dan Lokasi",
        "panel3" => "Kerja Sambilan vs Kerja Sepenuh masa",
        "panel4" => "Bilangan pekerja mengikut Tahun",
    ];
 ?>