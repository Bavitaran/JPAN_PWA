<?php
    return [
        "panel1" => "Overview of activities progress",
        "panel2" => "Hire By Department & Location",
        "panel3" => "Part time vs Full time",
        "panel4" => "Number of employees by Year",
    ];
 ?>